<p align="center">
    <img src="img/LogoPonpes_remove.png" width="200" max-width="90%" alt="OurRooms" />
</p>

<p align="center">
    <img src="https://api.netlify.com/api/v1/badges/fbfd05ff-08ed-497f-89b6-50cb6911d295/deploy-status" />
    <img src="https://img.shields.io/badge/Bootstrap-5.2.0-green.svg" />
    <img src="https://img.shields.io/badge/MDBootstrap-4.0.0-green.svg" />
    <img src="https://img.shields.io/badge/Platform-Website-green.svg?style=flat" />
</p>

Saat ini, setiap instansi sudah pasti memiliki website pribadi sebagai Company Profile mereka. Kami berinisiatif untuk membuatkan sebuah website Company Profile untuk instansi yang masih belum memiliki website tersebut. Setelah berdiskusi, kami sepakat untuk membuatkan website untuk sebuah pesantren dimana salah satu dari anggota kami belajar di pesantren tersebut. 

Pesantren Nurul Jadid Al - Mas’udiyah merupakan pondok untuk mempelajari ilmu agama Islam. Terletak di Sokaraja, Purwokerto Timur. 

Selain untuk menampilkan profile pesantren, website yang kami buat ini nantinya juga akan ada form sebagai sarana untuk pendaftaran santri baru.

# Target 
Pondok Pesantren Nurul Jadid Al - Mas'udiyah

# Penanggung Jawab
Pengasuh pondok: USTADZ MOH. UMAR SA'I

Ketua: KETUA YAYASAN TRIYONO, S.E.

# Link
Desain: https://bit.ly/UI-UX-Kelompok-5 <br>
Laporan: https://bit.ly/Laporan-Kelompok-5 <br>
Hosting dengan Netlify:  https://pesantrennuruljadid.netlify.app <br>
Hosting dengan GitHub Pages: https://se04b.github.io/UTS-DPW-K5/

# Pembagian Tugas
### Coding Website
1. Muhammad Irfani
2. Maulana Dimyati
3. Muhammad Nazar Alwi

### Wireframe dan Penentuan UI
1. Muhammad Zayyan Dafa Qiyamulail
2. Farhan Ardiyanto Wibowo
3. Muhammad Hauzan Mufid

### Feature
1. Home Page
    * Nama
    * Logo
    * Slogan
    * Gambar ponpes sebagai background
2. Fasilitas
3. Event
4. Pendaftaran
5. About Us
