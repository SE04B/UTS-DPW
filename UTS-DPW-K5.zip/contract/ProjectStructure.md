# Target 
Pondok Pesantren Nurul Jadid Al - Mas'udiyah

# Penanggung Jawab
Pengasuh pondok : USTADZ MOH. UMAR SA'I

Ketua : KETUA YAYASAN TRIYONO, S.E.

# Pembagian Tugas
## Coding Wbsite
1. Muhammad Irfani
2. Maulana Dimyati
3. Nazar Alwi

## Wireframe dan penentuan UI
1. Muhammad Zayyan Dafa
2. Farhan Ardiyanto
3. Hauzan MUhfid


## Feature Website
1. Home Page
1. Event
1. About Us
1. Pendaftaran

## Struktur Warna
1. Hijau 
eb