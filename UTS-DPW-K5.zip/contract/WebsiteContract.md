# Website Contract (Pondok)

## Narative
Ketika user mengunjungi halaman website, website menampilkan halaman home yang berisi 
### Story : Custumer ingin melihat halaman home page

Scenario website


Scenario mobile
halaman
