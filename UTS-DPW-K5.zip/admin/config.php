<?php

    $host = '127.0.0.1';
    $username = 'root';
    $password = '';
    $database = 'user';
    $connection = mysqli_connect($host,$username,$password,$database);

?>